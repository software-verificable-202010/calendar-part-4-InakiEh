﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CalendarPart2.Tests
{
    class MainWindow
    {
        int number = 1994;
        
        public int GetYearNumber()
        {
            int yearNumber = number;
            return yearNumber;
        }
    }
}
